
let btnclick = document.querySelector("button");

btnclick.addEventListener("click",() => {
    window.location.href="cbpage2.html";
    window.location.href="vegtarian.html";
    window.location.href="non-vegtarian.";
    window.location.href="starberry cake.html";
    window.location.href="Kimchi pancake.html ";
    window.location.href="vadapav.html";
    window.location.href="paratha.html";
    window.location.href="hyderabadi briyani.html";
    window.location.href="noodles.html"; 
});
